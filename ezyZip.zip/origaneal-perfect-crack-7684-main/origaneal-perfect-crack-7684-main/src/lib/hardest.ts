import { useEffect, useState } from "react";

export type HardestEntry = {
  id: number;
  mode: "Numeric" | "Alphabetic" | "Pattern";
  value: string;
  hashType?: string;
  detail?: string;
  attempts: number;
  elapsedMs: number;
  at: number;
};

const KEY = "cracklab.hardest";
const EVT = "cracklab:hardest";
const MAX = 10;

function read(): HardestEntry[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

function write(list: HardestEntry[]) {
  localStorage.setItem(KEY, JSON.stringify(list));
  window.dispatchEvent(new Event(EVT));
}

export function recordHardest(entry: Omit<HardestEntry, "id" | "at">) {
  if (typeof window === "undefined") return;
  const list = read();
  // dedupe by mode+value (keep best attempts count)
  const idx = list.findIndex((e) => e.mode === entry.mode && e.value === entry.value);
  if (idx >= 0 && list[idx].attempts >= entry.attempts) return;
  if (idx >= 0) list.splice(idx, 1);
  list.push({ ...entry, id: Date.now() + Math.random(), at: Date.now() });
  list.sort((a, b) => b.attempts - a.attempts);
  write(list.slice(0, MAX));
}

export function clearHardest() {
  write([]);
}

export function useHardest() {
  const [list, setList] = useState<HardestEntry[]>([]);
  useEffect(() => {
    setList(read());
    const handler = () => setList(read());
    window.addEventListener(EVT, handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener(EVT, handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return list;
}