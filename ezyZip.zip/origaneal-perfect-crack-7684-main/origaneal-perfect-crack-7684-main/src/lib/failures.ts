import { useEffect, useState } from "react";

export type FailureEntry = {
  id: number;
  mode: "Numeric" | "Alphabetic" | "Pattern";
  target: string;
  hashType?: string;
  detail?: string;
  attempts: number;
  elapsedMs: number;
  at: number;
};

const KEY = "cracklab.failures";
const EVT = "cracklab:failures";

function read(): FailureEntry[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

function write(list: FailureEntry[]) {
  localStorage.setItem(KEY, JSON.stringify(list.slice(0, 100)));
  window.dispatchEvent(new Event(EVT));
}

export function recordFailure(entry: Omit<FailureEntry, "id" | "at">) {
  if (typeof window === "undefined") return;
  const list = read();
  list.unshift({ ...entry, id: Date.now() + Math.random(), at: Date.now() });
  write(list);
}

export function clearFailures() {
  write([]);
}

export function useFailures() {
  const [list, setList] = useState<FailureEntry[]>([]);
  useEffect(() => {
    setList(read());
    const handler = () => setList(read());
    window.addEventListener(EVT, handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener(EVT, handler);
      window.removeEventListener("storage", handler);
    };
  }, []);
  return list;
}