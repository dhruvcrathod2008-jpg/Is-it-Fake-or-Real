import { Button } from "@/components/ui/button";
import { Terminal as TerminalIcon, ShieldCheck, Zap } from "lucide-react";

interface WelcomePageProps {
  onStart: () => void;
}

export function WelcomePage({ onStart }: WelcomePageProps) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center px-4 py-10 relative overflow-x-hidden">
      {/* Subtle grid background */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,255,136,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(0,255,136,0.5) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      <div className="relative z-10 flex flex-col items-center text-center max-w-2xl space-y-8">
        {/* Icon + Title */}
        <div className="flex flex-col items-center gap-4">
          <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center ring-1 ring-primary/20">
            <TerminalIcon className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold font-mono tracking-tight">
            CrackLab<span className="text-primary">_</span>
          </h1>
        </div>

        {/* Welcome message */}
        <div className="space-y-4">
          <p className="text-2xl md:text-3xl font-semibold leading-tight">
            Welcome
            <br />
            <span className="text-primary">to all who dare to make the strongest password</span>
          </p>

          <p className="text-muted-foreground text-base md:text-lg max-w-lg mx-auto leading-relaxed">
            This is where the strongest passwords are born.
          </p>

          <p className="text-foreground/90 text-base md:text-lg max-w-lg mx-auto leading-relaxed">
            We welcome you here to try your luck in making your strongest passwords.
          </p>
        </div>

        {/* Feature chips */}
        <div className="flex flex-wrap justify-center gap-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-card border border-border text-sm text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5 text-primary" />
            Educational
          </span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-card border border-border text-sm text-muted-foreground">
            <Zap className="h-3.5 w-3.5 text-primary" />
            Browser-only
          </span>
        </div>

        {/* Start button */}
        <Button
          onClick={onStart}
          className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold text-lg px-8 py-6 h-auto rounded-xl shadow-lg shadow-primary/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          Go ahead
        </Button>
      </div>
    </div>
  );
}
