import { CheckCircle2 } from "lucide-react";

export function CrackedBanner({ value, label = "Password cracked" }: { value: string; label?: string }) {
  return (
    <div className="fade-in rounded-md border-2 border-emerald-400 bg-emerald-500/15 px-4 py-3 flex items-center gap-3 pulse-glow">
      <CheckCircle2 className="h-6 w-6 text-emerald-400 shrink-0" />
      <div className="font-mono">
        <div className="text-xs uppercase tracking-wider text-emerald-300/80">{label}</div>
        <div className="text-emerald-300 text-lg font-bold break-all">{value}</div>
      </div>
    </div>
  );
}