import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

export type LogLine = { id: number; text: string; kind?: "info" | "ok" | "err" | "dim" };

export function Terminal({ lines, className }: { lines: LogLine[]; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [lines]);
  return (
    <div
      ref={ref}
      className={cn(
        "terminal font-mono text-xs leading-relaxed rounded-md border border-border p-3 overflow-y-auto",
        className,
      )}
    >
      {lines.length === 0 && <div className="opacity-40">// awaiting input…</div>}
      {lines.map((l) => (
        <div
          key={l.id}
          className={cn(
            "whitespace-pre-wrap",
            l.kind === "ok" && "text-emerald-400 font-bold",
            l.kind === "err" && "text-red-400",
            l.kind === "dim" && "opacity-60",
          )}
        >
          {l.text}
        </div>
      ))}
    </div>
  );
}