import { useRef, useState } from "react";
import confetti from "canvas-confetti";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Terminal, type LogLine } from "./Terminal";
import { CrackedBanner } from "./CrackedBanner";
import { hashWith, makeHasher, type HashType } from "@/lib/cracklab";
import { recordFailure } from "@/lib/failures";
import { recordHardest } from "@/lib/hardest";

const speedToDelay = (s: number) => (s === 0 ? 30 : s === 1 ? 2 : 0);
const speedToBatch = (s: number) => (s === 0 ? 200 : s === 1 ? 2000 : 20000);
const LOWER = "abcdefghijklmnopqrstuvwxyz";
const UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const DIGITS = "0123456789";
const SYMBOLS = "!@#$%";

type WorkerKind = "front" | "middle" | "back";
const WORKER_LABEL: Record<WorkerKind, string> = {
  front: "Terminal 1 — from front",
  middle: "Terminal 2 — from middle",
  back: "Terminal 3 — from behind",
};

function indexToCandidate(n: number, len: number, charset: string): string {
  const base = charset.length;
  let out = "";
  for (let p = len - 1; p >= 0; p--) {
    out = charset[n % base] + out;
    n = Math.floor(n / base);
  }
  return out;
}

export function AlphabeticCracker() {
  const [pwd, setPwd] = useState("");
  const [hashType, setHashType] = useState<HashType>("plain");
  const [maxLen, setMaxLen] = useState(3);
  const [speed, setSpeed] = useState(2);
  const [useLower, setUseLower] = useState(true);
  const [useUpper, setUseUpper] = useState(false);
  const [useDigits, setUseDigits] = useState(true);
  const [useSymbols, setUseSymbols] = useState(false);
  const [running, setRunning] = useState(false);
  const [linesFront, setLinesFront] = useState<LogLine[]>([]);
  const [linesMiddle, setLinesMiddle] = useState<LogLine[]>([]);
  const [linesBack, setLinesBack] = useState<LogLine[]>([]);
  const [attempts, setAttempts] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [keyspace, setKeyspace] = useState(0);
  const [cracked, setCracked] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const stopRef = useRef(false);
  const idRef = useRef(0);

  const charset =
    (useLower ? LOWER : "") + (useUpper ? UPPER : "") + (useDigits ? DIGITS : "") + (useSymbols ? SYMBOLS : "");

  const setterFor = (w: WorkerKind) =>
    w === "front" ? setLinesFront : w === "middle" ? setLinesMiddle : setLinesBack;
  const pushTo = (w: WorkerKind, text: string, kind?: LogLine["kind"]) =>
    setterFor(w)((l) => {
      const next = [...l, { id: ++idRef.current, text, kind }];
      return next.length > 200 ? next.slice(-200) : next;
    });
  const pushAll = (text: string, kind?: LogLine["kind"]) => {
    pushTo("front", text, kind);
    pushTo("middle", text, kind);
    pushTo("back", text, kind);
  };

  const reset = () => {
    stopRef.current = true;
    setRunning(false);
    setLinesFront([]); setLinesMiddle([]); setLinesBack([]);
    setAttempts(0);
    setElapsed(0);
    setKeyspace(0);
    setCracked(null);
    setError(null);
  };

  const start = async () => {
    setError(null);
    if (!pwd) { setError("Enter a password to crack"); return; }
    if (!charset) { setError("Select at least one character set"); return; }
    if (pwd.length > maxLen) { setError(`Password longer than max length ${maxLen}`); return; }
    for (const c of pwd) if (!charset.includes(c)) { setError(`Character "${c}" not in selected charset`); return; }

    stopRef.current = false;
    setLinesFront([]); setLinesMiddle([]); setLinesBack([]);
    setAttempts(0); setElapsed(0); setCracked(null); setRunning(true);

    const total = (() => { let t = 0; for (let l = 1; l <= maxLen; l++) t += Math.pow(charset.length, l); return t; })();
    setKeyspace(total);

    pushAll(`▸ charset (${charset.length}): ${charset}`, "dim");
    pushAll(`▸ keyspace (1..${maxLen}): ${total.toLocaleString()}`, "dim");
    pushAll(`▸ 3 terminals racing in parallel (keyspace split in thirds)`, "dim");

    const target = await hashWith(hashType, pwd);
    const hasher = await makeHasher(hashType);
    const delay = speedToDelay(speed);
    const batch = speedToBatch(speed);
    const t0 = performance.now();
    const counts: Record<WorkerKind, number> = { front: 0, middle: 0, back: 0 };
    const foundRef: { value: string | null; by: WorkerKind | null } = { value: null, by: null };

    const totalAttempts = () => counts.front + counts.middle + counts.back;

    const runWorker = async (w: WorkerKind) => {
      for (let len = 1; len <= maxLen; len++) {
        const sz = Math.pow(charset.length, len);
        // partition this length's keyspace into thirds
        const a = Math.floor(sz / 3);
        const b = Math.floor((2 * sz) / 3);
        let from: number, to: number, step: 1 | -1;
        if (w === "front") { from = 0; to = a; step = 1; }
        else if (w === "middle") { from = a; to = b; step = 1; }
        else { from = sz - 1; to = b - 1; step = -1; }

        let i = from;
        while (step === 1 ? i < to : i > to) {
          if (stopRef.current || foundRef.value) return;
          const candidate = indexToCandidate(i, len, charset);
          counts[w]++;
          const h = await hasher(candidate);
          if (counts[w] % batch === 0) {
            pushTo(w, `Trying: ${candidate}`);
            setAttempts(totalAttempts());
            setElapsed(performance.now() - t0);
            await new Promise((r) => setTimeout(r, 0));
          } else if (delay > 0 && counts[w] % 25 === 0) {
            pushTo(w, `Trying: ${candidate}`);
          }
          if (h === target) {
            foundRef.value = candidate;
            foundRef.by = w;
            return;
          }
          if (delay > 0) await new Promise((r) => setTimeout(r, delay));
          i += step;
        }
      }
    };

    await Promise.all([runWorker("front"), runWorker("middle"), runWorker("back")]);

    const ms = performance.now() - t0;
    const count = totalAttempts();
    setAttempts(count);
    setElapsed(ms);
    if (stopRef.current && !foundRef.value) {
      pushAll("✖ stopped by user", "err");
    }
    if (foundRef.value) {
      const by = foundRef.by!;
      pushTo(by, `✔ FOUND: ${foundRef.value}`, "ok");
      pushAll(`✔ Cracked by ${WORKER_LABEL[by]}`, "ok");
      setCracked(foundRef.value);
      confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
      recordHardest({
        mode: "Alphabetic",
        value: foundRef.value,
        hashType,
        detail: `charset(${charset.length}) · max len ${maxLen}`,
        attempts: count,
        elapsedMs: ms,
      });
    } else if (!stopRef.current) {
      pushAll("Not found in keyspace — did you select the right hash type / charset?", "err");
      recordFailure({
        mode: "Alphabetic",
        target: pwd,
        hashType,
        detail: `charset(${charset.length}) · max len ${maxLen} · keyspace ${total.toLocaleString()}`,
        attempts: count,
        elapsedMs: ms,
      });
    }
    setRunning(false);
  };

  const aps = elapsed > 0 ? Math.round((attempts / elapsed) * 1000) : 0;
  const pct = keyspace ? Math.min(100, (attempts / keyspace) * 100) : 0;
  const remaining = keyspace - attempts;
  const eta = aps > 0 ? remaining / aps : 0;

  return (
    <div className="grid gap-4 md:grid-cols-2 fade-in">
      <Card className="p-4 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="alpha-pwd">Alphabetic password (max 8 chars)</Label>
          <Input
            id="alpha-pwd"
            value={pwd}
            placeholder="e.g. ab12"
            onChange={(e) => setPwd(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !running && start()}
            disabled={running}
            className="font-mono border-2 border-primary"
            maxLength={8}
          />
          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>Hash type</Label>
            <Select value={hashType} onValueChange={(v) => setHashType(v as HashType)} disabled={running}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="plain">Plain text</SelectItem>
                <SelectItem value="MD5">MD5</SelectItem>
                <SelectItem value="SHA-1">SHA-1</SelectItem>
                <SelectItem value="SHA-256">SHA-256</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Max length (1–8)</Label>
            <Input
              type="number" min={1} max={8} value={maxLen}
              onChange={(e) => setMaxLen(Math.max(1, Math.min(8, Number(e.target.value) || 1)))}
              disabled={running}
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label className="text-xs">Character sets</Label>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <label className="flex items-center gap-2"><Checkbox checked={useLower} onCheckedChange={(v) => setUseLower(!!v)} disabled={running} /> lowercase a–z</label>
            <label className="flex items-center gap-2"><Checkbox checked={useUpper} onCheckedChange={(v) => setUseUpper(!!v)} disabled={running} /> uppercase A–Z</label>
            <label className="flex items-center gap-2"><Checkbox checked={useDigits} onCheckedChange={(v) => setUseDigits(!!v)} disabled={running} /> digits 0–9</label>
            <label className="flex items-center gap-2"><Checkbox checked={useSymbols} onCheckedChange={(v) => setUseSymbols(!!v)} disabled={running} /> symbols !@#$%</label>
          </div>
          {maxLen >= 6 && (
            <p className="text-xs text-amber-400">⚠ Length {maxLen} with the selected charset can be astronomically large — use Fast and a small charset, or Stop anytime.</p>
          )}
        </div>
        <div className="space-y-2">
          <Label>Speed: {["Slow", "Medium", "Fast"][speed]}</Label>
          <Slider value={[speed]} min={0} max={2} step={1} onValueChange={(v) => setSpeed(v[0])} disabled={running} />
        </div>
        <div className="flex gap-2">
          {!running ? (
            <Button onClick={start} className="bg-emerald-500 hover:bg-emerald-600 text-black font-semibold">Start cracking</Button>
          ) : (
            <Button onClick={() => (stopRef.current = true)} variant="destructive">Stop</Button>
          )}
          <Button onClick={reset} variant="outline" disabled={running}>Reset</Button>
        </div>
      </Card>
      <Card className="p-4 space-y-3">
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <Badge variant="secondary" className="font-mono">Attempts: {attempts.toLocaleString()}</Badge>
          <Badge variant="secondary" className="font-mono">Elapsed: {(elapsed / 1000).toFixed(2)}s</Badge>
          <Badge variant="secondary" className="font-mono">{aps.toLocaleString()} / sec</Badge>
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-xs font-mono text-muted-foreground">
            <span>Keyspace covered</span>
            <span>{pct.toFixed(2)}% · ETA {eta > 0 && isFinite(eta) ? `${Math.round(eta)}s` : "—"}</span>
          </div>
          <Progress value={pct} />
        </div>
        {cracked && <CrackedBanner value={cracked} />}
        <div className="space-y-2">
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.front}</div>
            <Terminal lines={linesFront} className="h-32" />
          </div>
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.middle}</div>
            <Terminal lines={linesMiddle} className="h-32" />
          </div>
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.back}</div>
            <Terminal lines={linesBack} className="h-32" />
          </div>
        </div>
      </Card>
    </div>
  );
}