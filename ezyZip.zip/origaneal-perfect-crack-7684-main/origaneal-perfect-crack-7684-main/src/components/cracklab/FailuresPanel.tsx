import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { clearFailures, useFailures } from "@/lib/failures";
import { clearHardest, useHardest } from "@/lib/hardest";
import { Ghost, Trash2, Trophy } from "lucide-react";

export function FailuresPanel() {
  const failures = useFailures();
  const hardest = useHardest();
  const medal = (i: number) => (i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`);

  return (
    <div className="fade-in space-y-4">
      <Card className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <h2 className="text-base font-bold font-mono flex items-center gap-2">
              <Trophy className="h-4 w-4 text-amber-400" />
              Hardest cracks
            </h2>
            <p className="text-xs text-muted-foreground mt-1">
              Top 10 successful cracks ranked by attempts taken — the closer to the end of the keyspace, the harder
              it was to guess.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="font-mono">{hardest.length} / 10</Badge>
            <Button size="sm" variant="outline" onClick={clearHardest} disabled={hardest.length === 0}>
              <Trash2 className="h-3.5 w-3.5 mr-1" /> Clear
            </Button>
          </div>
        </div>
        {hardest.length === 0 ? (
          <p className="text-sm text-muted-foreground font-mono py-4 text-center">
            No cracks recorded yet. Crack something to start the leaderboard.
          </p>
        ) : (
          <ol className="divide-y divide-border">
            {hardest.map((h, i) => (
              <li key={h.id} className="py-3 flex items-start gap-3">
                <div className="text-lg font-mono w-10 text-center shrink-0">{medal(i)}</div>
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="bg-amber-500/15 text-amber-300 border-amber-500/30 font-mono">{h.mode}</Badge>
                    {h.hashType && <Badge variant="outline" className="font-mono text-xs">{h.hashType}</Badge>}
                    <span className="font-mono text-sm break-all">{h.value}</span>
                  </div>
                  <div className="text-xs text-muted-foreground font-mono">
                    {h.attempts.toLocaleString()} attempts · {(h.elapsedMs / 1000).toFixed(2)}s
                    {h.detail ? ` · ${h.detail}` : ""}
                  </div>
                </div>
              </li>
            ))}
          </ol>
        )}
      </Card>

      <Card className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <h2 className="text-base font-bold font-mono flex items-center gap-2">
              <Ghost className="h-4 w-4 text-emerald-400" />
              Uncracked vault
            </h2>
            <p className="text-xs text-muted-foreground mt-1">
              Targets the simulator exhausted its keyspace on without finding a match — usually because the password
              was longer than your max length, used a charset you didn't enable, or the hash didn't match.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="font-mono">{failures.length} stored</Badge>
            <Button
              size="sm"
              variant="outline"
              onClick={clearFailures}
              disabled={failures.length === 0}
            >
              <Trash2 className="h-3.5 w-3.5 mr-1" /> Clear
            </Button>
          </div>
        </div>
      </Card>

      {failures.length === 0 ? (
        <Card className="p-8 text-center text-sm text-muted-foreground font-mono">
          No failed runs yet. When a crack finishes without a match, it's archived here.
        </Card>
      ) : (
        <Card className="p-0">
          <ScrollArea className="h-[28rem]">
            <ul className="divide-y divide-border">
              {failures.map((f) => (
                <li key={f.id} className="p-4 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="bg-emerald-500/15 text-emerald-300 border-emerald-500/30 font-mono">
                      {f.mode}
                    </Badge>
                    {f.hashType && (
                      <Badge variant="outline" className="font-mono text-xs">{f.hashType}</Badge>
                    )}
                    <span className="font-mono text-sm break-all">{f.target}</span>
                  </div>
                  {f.detail && (
                    <p className="text-xs text-muted-foreground font-mono">{f.detail}</p>
                  )}
                  <div className="text-xs text-muted-foreground font-mono">
                    {f.attempts.toLocaleString()} attempts · {(f.elapsedMs / 1000).toFixed(2)}s ·{" "}
                    {new Date(f.at).toLocaleString()}
                  </div>
                </li>
              ))}
            </ul>
          </ScrollArea>
        </Card>
      )}
    </div>
  );
}