import { useMemo, useRef } from "react";

export function PatternGrid({
  active = [],
  highlight,
  interactive = false,
  onChange,
  size = 220,
}: {
  active?: number[];
  highlight?: number;
  interactive?: boolean;
  onChange?: (next: number[]) => void;
  size?: number;
}) {
  const dots = useMemo(() => Array.from({ length: 9 }, (_, i) => i + 1), []);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const draggingRef = useRef(false);
  const activeRef = useRef<number[]>(active);
  activeRef.current = active;

  const pos = (n: number) => {
    const r = Math.floor((n - 1) / 3);
    const c = (n - 1) % 3;
    const gap = size / 4;
    return { x: gap + c * gap, y: gap + r * gap };
  };

  const hitTest = (clientX: number, clientY: number): number | null => {
    const svg = svgRef.current;
    if (!svg) return null;
    const rect = svg.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * size;
    const y = ((clientY - rect.top) / rect.height) * size;
    const hitR = size / 4 / 2; // half a cell — generous touch target
    for (const n of dots) {
      const p = pos(n);
      const dx = x - p.x;
      const dy = y - p.y;
      if (dx * dx + dy * dy <= hitR * hitR) return n;
    }
    return null;
  };

  const addDot = (n: number) => {
    const cur = activeRef.current;
    if (cur.includes(n) || cur.length >= 9) return;
    onChange?.([...cur, n]);
  };

  const handleDown = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!interactive || !onChange) return;
    e.preventDefault();
    svgRef.current?.setPointerCapture(e.pointerId);
    draggingRef.current = true;
    const n = hitTest(e.clientX, e.clientY);
    onChange(n ? [n] : []);
  };

  const handleMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!interactive || !draggingRef.current) return;
    const n = hitTest(e.clientX, e.clientY);
    if (n) addDot(n);
  };

  const handleUp = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!interactive) return;
    draggingRef.current = false;
    try { svgRef.current?.releasePointerCapture(e.pointerId); } catch { /* noop */ }
  };

  const path = active.map((n, i) => `${i === 0 ? "M" : "L"} ${pos(n).x} ${pos(n).y}`).join(" ");

  return (
    <svg
      ref={svgRef}
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className="touch-none select-none"
      style={{ touchAction: "none" }}
      onPointerDown={handleDown}
      onPointerMove={handleMove}
      onPointerUp={handleUp}
      onPointerCancel={handleUp}
    >
      {path && <path d={path} stroke="#00ff88" strokeWidth={3} fill="none" opacity={0.7} />}
      {dots.map((n) => {
        const { x, y } = pos(n);
        const isActive = active.includes(n);
        const isHl = highlight === n;
        return (
          <g key={n}>
            <circle
              cx={x} cy={y} r={interactive ? 22 : 16}
              fill={isActive ? "#00ff88" : "transparent"}
              stroke={isHl ? "#00d4ff" : isActive ? "#00ff88" : "#475569"}
              strokeWidth={isHl ? 3 : 2}
              opacity={isHl ? 1 : isActive ? 1 : 0.7}
              style={{ cursor: interactive ? "pointer" : "default", transition: "stroke .1s, fill .1s", pointerEvents: "none" }}
            />
            <text x={x} y={y + 4} textAnchor="middle" fontSize={10} fill={isActive ? "#0d1117" : "#94a3b8"} className="font-mono" style={{ pointerEvents: "none" }}>{n}</text>
          </g>
        );
      })}
      {/* Transparent hit layer ensures the svg receives pointer events across the whole grid */}
      <rect x={0} y={0} width={size} height={size} fill="transparent" style={{ pointerEvents: "none" }} />
    </svg>
  );
}