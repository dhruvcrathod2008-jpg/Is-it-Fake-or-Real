import { useRef, useState } from "react";
import confetti from "canvas-confetti";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Terminal, type LogLine } from "./Terminal";
import { CrackedBanner } from "./CrackedBanner";
import { PatternGrid } from "./PatternGrid";
import { canMove, TOTAL_PATTERNS } from "@/lib/cracklab";
import { recordFailure } from "@/lib/failures";
import { recordHardest } from "@/lib/hardest";

const speedToDelay = (s: number) => (s === 0 ? 40 : 0);

type WorkerKind = "front" | "middle" | "back";
const WORKER_LABEL: Record<WorkerKind, string> = {
  front: "Terminal 1 — from front (starts 1–3)",
  middle: "Terminal 2 — from middle (starts 4–6)",
  back: "Terminal 3 — from behind (starts 9–7)",
};

function* enumerateFromStarts(starts: number[], min: number, max: number): Generator<number[]> {
  function* dfs(path: number[], visited: Set<number>): Generator<number[]> {
    if (path.length >= min) yield path.slice();
    if (path.length === max) return;
    for (let n = 1; n <= 9; n++) {
      if (!canMove(path[path.length - 1], n, visited)) continue;
      visited.add(n); path.push(n);
      yield* dfs(path, visited);
      path.pop(); visited.delete(n);
    }
  }
  for (const s of starts) {
    const v = new Set<number>([s]);
    yield* dfs([s], v);
  }
}

export function PatternCracker() {
  const [draft, setDraft] = useState<number[]>([]);
  const [target, setTarget] = useState<number[] | null>(null);
  const [speed, setSpeed] = useState(1);
  const [running, setRunning] = useState(false);
  const [current, setCurrent] = useState<number[]>([]);
  const [highlight, setHighlight] = useState<number | undefined>();
  const [linesFront, setLinesFront] = useState<LogLine[]>([]);
  const [linesMiddle, setLinesMiddle] = useState<LogLine[]>([]);
  const [linesBack, setLinesBack] = useState<LogLine[]>([]);
  const [attempts, setAttempts] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [cracked, setCracked] = useState<number[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const stopRef = useRef(false);
  const idRef = useRef(0);

  const setterFor = (w: WorkerKind) =>
    w === "front" ? setLinesFront : w === "middle" ? setLinesMiddle : setLinesBack;
  const pushTo = (w: WorkerKind, text: string, kind?: LogLine["kind"]) =>
    setterFor(w)((l) => {
      const next = [...l, { id: ++idRef.current, text, kind }];
      return next.length > 200 ? next.slice(-200) : next;
    });
  const pushAll = (text: string, kind?: LogLine["kind"]) => {
    pushTo("front", text, kind);
    pushTo("middle", text, kind);
    pushTo("back", text, kind);
  };

  const reset = () => {
    stopRef.current = true;
    setRunning(false); setDraft([]); setTarget(null); setCurrent([]); setHighlight(undefined);
    setLinesFront([]); setLinesMiddle([]); setLinesBack([]);
    setAttempts(0); setElapsed(0); setCracked(null); setError(null);
  };

  const lockTarget = () => {
    if (draft.length < 4) { setError("Pattern must have at least 4 dots"); return; }
    setError(null);
    setTarget(draft);
    pushAll(`▸ target locked: ${draft.join(" → ")}`, "dim");
  };

  const start = async () => {
    if (!target) { setError("Lock a target pattern first"); return; }
    stopRef.current = false;
    setLinesFront([]); setLinesMiddle([]); setLinesBack([]);
    setAttempts(0); setElapsed(0); setCracked(null); setRunning(true);
    pushAll(`▸ enumerating valid 4–9 dot patterns…`, "dim");
    pushAll(`▸ 3 terminals racing in parallel (split by starting dot)`, "dim");
    const delay = speedToDelay(speed);
    const t0 = performance.now();
    const targetStr = target.join(",");

    const counts: Record<WorkerKind, number> = { front: 0, middle: 0, back: 0 };
    const foundRef: { value: number[] | null; by: WorkerKind | null } = { value: null, by: null };
    const totalAttempts = () => counts.front + counts.middle + counts.back;

    const STARTS: Record<WorkerKind, number[]> = {
      front: [1, 2, 3],
      middle: [4, 5, 6],
      back: [9, 8, 7],
    };

    const runWorker = async (w: WorkerKind) => {
      for (const pat of enumerateFromStarts(STARTS[w], 4, 9)) {
        if (stopRef.current || foundRef.value) return;
        counts[w]++;
        if (delay > 0) {
          setCurrent(pat);
          setHighlight(pat[pat.length - 1]);
          pushTo(w, `Trying: ${pat.join("→")}`);
          await new Promise((r) => setTimeout(r, delay));
        } else if (counts[w] % 250 === 0) {
          setCurrent(pat);
          setAttempts(totalAttempts());
          setElapsed(performance.now() - t0);
          pushTo(w, `Trying: ${pat.join("→")}`);
          await new Promise((r) => setTimeout(r, 0));
        }
        if (pat.join(",") === targetStr) {
          foundRef.value = pat.slice();
          foundRef.by = w;
          return;
        }
      }
    };

    await Promise.all([runWorker("front"), runWorker("middle"), runWorker("back")]);

    const ms = performance.now() - t0;
    const count = totalAttempts();
    setAttempts(count); setElapsed(ms);
    if (stopRef.current && !foundRef.value) {
      pushAll("✖ stopped by user", "err");
    }
    if (foundRef.value) {
      const by = foundRef.by!;
      setCurrent(foundRef.value); setHighlight(undefined);
      pushTo(by, `✔ MATCH: ${foundRef.value.join(" → ")}`, "ok");
      pushAll(`✔ Cracked by ${WORKER_LABEL[by]}`, "ok");
      setCracked(foundRef.value);
      confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
      recordHardest({
        mode: "Pattern",
        value: foundRef.value.join(" → "),
        detail: `${foundRef.value.length} dots`,
        attempts: count,
        elapsedMs: ms,
      });
    } else if (!stopRef.current) {
      pushAll("Pattern not found.", "err");
      recordFailure({
        mode: "Pattern",
        target: target.join(" → "),
        detail: `${target.length} dots · search space ${TOTAL_PATTERNS.toLocaleString()}`,
        attempts: count,
        elapsedMs: ms,
      });
    }
    setRunning(false);
  };

  const aps = elapsed > 0 ? Math.round((attempts / elapsed) * 1000) : 0;

  return (
    <div className="grid gap-4 md:grid-cols-2 fade-in">
      <Card className="p-4 space-y-4">
        <div>
          <Label>Draw your pattern (4–9 dots)</Label>
          <p className="text-xs text-muted-foreground">Click & drag across dots. Android knight-rule applies.</p>
        </div>
        <div className="flex justify-center bg-[#07090f] rounded-md border-2 border-primary p-3">
          <PatternGrid interactive={!target && !running} active={target ?? draft} onChange={setDraft} />
        </div>
        <div className="text-xs font-mono text-muted-foreground">
          Your pattern: {(target ?? draft).length ? (target ?? draft).join(" → ") : "—"}
        </div>
        {error && <p className="text-xs text-destructive">{error}</p>}
        <div className="flex gap-2 flex-wrap">
          {!target && <Button onClick={lockTarget} variant="secondary">Set as target</Button>}
          {target && !running && <Button onClick={() => { setTarget(null); setDraft([]); }} variant="outline">Edit pattern</Button>}
          {!running ? (
            <Button onClick={start} className="bg-emerald-500 hover:bg-emerald-600 text-black font-semibold" disabled={!target}>Start cracking</Button>
          ) : (
            <Button onClick={() => (stopRef.current = true)} variant="destructive">Stop</Button>
          )}
          <Button onClick={reset} variant="outline" disabled={running}>Reset</Button>
        </div>
        <div className="space-y-2">
          <Label>Speed: {speed === 0 ? "Slow (animated)" : "Fast"}</Label>
          <Slider value={[speed]} min={0} max={1} step={1} onValueChange={(v) => setSpeed(v[0])} disabled={running} />
        </div>
      </Card>
      <Card className="p-4 space-y-3">
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <Badge variant="secondary" className="font-mono">Attempts: {attempts.toLocaleString()}</Badge>
          <Badge variant="secondary" className="font-mono">Elapsed: {(elapsed / 1000).toFixed(2)}s</Badge>
          <Badge variant="secondary" className="font-mono">{aps.toLocaleString()} pat/s</Badge>
          <Badge variant="outline" className="font-mono">Total space: {TOTAL_PATTERNS.toLocaleString()}</Badge>
        </div>
        <div className="flex justify-center bg-[#07090f] rounded-md border border-border p-3">
          <PatternGrid active={current} highlight={highlight} />
        </div>
        {cracked && <CrackedBanner value={cracked.join(" → ")} label="Pattern matched" />}
        <div className="space-y-2">
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.front}</div>
            <Terminal lines={linesFront} className="h-28" />
          </div>
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.middle}</div>
            <Terminal lines={linesMiddle} className="h-28" />
          </div>
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.back}</div>
            <Terminal lines={linesBack} className="h-28" />
          </div>
        </div>
      </Card>
    </div>
  );
}