import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card } from "@/components/ui/card";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

const keyspaceData = [
  { name: "4-digit PIN", value: 10000 },
  { name: "4-char lower", value: 456976 },
  { name: "Android pattern", value: 389112 },
  { name: "6-char alphanum", value: 56800235584 },
];

export function HowItWorks() {
  return (
    <Card className="p-6 fade-in">
      <Accordion type="single" collapsible defaultValue="s1">
        <AccordionItem value="s1">
          <AccordionTrigger>1. What is a brute-force attack?</AccordionTrigger>
          <AccordionContent className="space-y-3 text-sm leading-relaxed">
            <p>
              A brute-force attack tries every possible combination until one matches — exactly like a thief
              spinning a 3-digit padlock from 000 to 999. It always works <em>eventually</em>; the only question
              is whether "eventually" means milliseconds or millennia.
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono border border-border rounded-md">
                <thead className="bg-muted">
                  <tr><th className="p-2 text-left">Password</th><th className="p-2 text-left">Combinations</th><th className="p-2 text-left">Time @ 1M/s</th></tr>
                </thead>
                <tbody>
                  <tr><td className="p-2 border-t border-border">4 digits</td><td className="p-2 border-t border-border">10,000</td><td className="p-2 border-t border-border">0.01 s</td></tr>
                  <tr><td className="p-2 border-t border-border">6 lowercase</td><td className="p-2 border-t border-border">308,915,776</td><td className="p-2 border-t border-border">5 min</td></tr>
                  <tr><td className="p-2 border-t border-border">8 lower+digits</td><td className="p-2 border-t border-border">2.8 × 10¹²</td><td className="p-2 border-t border-border">33 days</td></tr>
                  <tr><td className="p-2 border-t border-border">12 mixed</td><td className="p-2 border-t border-border">3.2 × 10²³</td><td className="p-2 border-t border-border">10 billion years</td></tr>
                </tbody>
              </table>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="s2">
          <AccordionTrigger>2. What are hash functions?</AccordionTrigger>
          <AccordionContent className="space-y-3 text-sm leading-relaxed">
            <p>
              A hash function is a one-way "fingerprint" of data. The same input always produces the same
              hash, but you can't reverse it. Web servers store hashes — not raw passwords — so a database
              leak doesn't immediately expose your password.
            </p>
            <ul className="space-y-1 list-disc pl-5">
              <li><b>MD5</b> — 128 bits, fast, completely broken for security.</li>
              <li><b>SHA-1</b> — 160 bits, deprecated; collisions found in 2017.</li>
              <li><b>SHA-256</b> — 256 bits, still safe as a building block but too fast for passwords.</li>
            </ul>
            <div className="font-mono text-xs bg-[#07090f] p-3 rounded-md border border-border space-y-1">
              <div>"password" → MD5:</div>
              <div className="text-emerald-400">5f4dcc3b5aa765d61d8327deb882cf99</div>
            </div>
            <p>
              Why hashing isn't enough: attackers precompute huge tables ("rainbow tables") mapping common
              passwords to their hashes. The fix is <b>salt</b> + a slow algorithm like bcrypt or Argon2.
            </p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="s3">
          <AccordionTrigger>3. Why do numeric / alphabetic / pattern locks have different strengths?</AccordionTrigger>
          <AccordionContent className="space-y-3 text-sm leading-relaxed">
            <p>Strength is governed by the size of the <b>keyspace</b> — the count of all possible secrets.</p>
            <ul className="space-y-1 list-disc pl-5">
              <li>4-digit PIN → 10⁴ = <b>10,000</b> combinations</li>
              <li>4-char lowercase → 26⁴ = <b>456,976</b> combinations</li>
              <li>Android pattern (4–9 dots) → <b>389,112</b> valid patterns</li>
            </ul>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={keyspaceData} margin={{ top: 10, right: 10, bottom: 30, left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="name" tick={{ fill: "#94a3b8", fontSize: 11 }} angle={-15} textAnchor="end" />
                  <YAxis scale="log" domain={[1, "auto"]} tick={{ fill: "#94a3b8", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "#161b22", border: "1px solid #334155", fontSize: 12 }} formatter={(v: number) => v.toLocaleString()} />
                  <Bar dataKey="value" fill="#00ff88" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="s4">
          <AccordionTrigger>4. How to make passwords stronger</AccordionTrigger>
          <AccordionContent className="space-y-3 text-sm leading-relaxed">
            <p>
              Keyspace grows <b>exponentially</b> with length: <code className="font-mono">charset^length</code>.
              Adding one character to a 10-char password multiplies the attacker's work by the charset size.
            </p>
            <ul className="space-y-1 list-disc pl-5">
              <li>Use a password <b>manager</b> + long random passwords (16+ chars).</li>
              <li>For servers: store passwords with <b>bcrypt</b> or <b>Argon2</b> — slow, salted, GPU-resistant.</li>
              <li>Turn on <b>multi-factor authentication</b> everywhere.</li>
              <li>Check exposure at{" "}
                <a href="https://haveibeenpwned.com" target="_blank" rel="noreferrer" className="text-emerald-400 underline">
                  haveibeenpwned.com
                </a>.
              </li>
            </ul>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </Card>
  );
}