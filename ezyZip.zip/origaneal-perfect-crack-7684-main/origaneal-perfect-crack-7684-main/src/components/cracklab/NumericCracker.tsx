import { useRef, useState } from "react";
import confetti from "canvas-confetti";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Terminal, type LogLine } from "./Terminal";
import { CrackedBanner } from "./CrackedBanner";
import { hashWith, makeHasher, type HashType } from "@/lib/cracklab";
import { recordFailure } from "@/lib/failures";
import { recordHardest } from "@/lib/hardest";

const speedToDelay = (s: number) => (s === 0 ? 60 : s === 1 ? 8 : 0);
const speedToBatch = (s: number) => (s === 0 ? 50 : s === 1 ? 500 : 5000);

type WorkerKind = "front" | "middle" | "back";
const WORKER_LABEL: Record<WorkerKind, string> = {
  front: "Terminal 1 — from front",
  middle: "Terminal 2 — from middle",
  back: "Terminal 3 — from behind",
};

export function NumericCracker() {
  const [pwd, setPwd] = useState("");
  const [hashType, setHashType] = useState<HashType>("plain");
  const [maxDigits, setMaxDigits] = useState(4);
  const [speed, setSpeed] = useState(2);
  const [running, setRunning] = useState(false);
  const [linesFront, setLinesFront] = useState<LogLine[]>([]);
  const [linesMiddle, setLinesMiddle] = useState<LogLine[]>([]);
  const [linesBack, setLinesBack] = useState<LogLine[]>([]);
  const [attempts, setAttempts] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [cracked, setCracked] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const stopRef = useRef(false);
  const idRef = useRef(0);

  const setterFor = (w: WorkerKind) =>
    w === "front" ? setLinesFront : w === "middle" ? setLinesMiddle : setLinesBack;
  const pushTo = (w: WorkerKind, text: string, kind?: LogLine["kind"]) =>
    setterFor(w)((l) => {
      const next = [...l, { id: ++idRef.current, text, kind }];
      return next.length > 200 ? next.slice(-200) : next;
    });
  const pushAll = (text: string, kind?: LogLine["kind"]) => {
    pushTo("front", text, kind);
    pushTo("middle", text, kind);
    pushTo("back", text, kind);
  };

  const reset = () => {
    stopRef.current = true;
    setRunning(false);
    setLinesFront([]); setLinesMiddle([]); setLinesBack([]);
    setAttempts(0);
    setElapsed(0);
    setCracked(null);
    setError(null);
  };

  const start = async () => {
    setError(null);
    if (!/^\d+$/.test(pwd)) { setError("Only digits allowed"); return; }
    if (pwd.length > maxDigits) { setError(`Password is ${pwd.length} digits but max is ${maxDigits}`); return; }
    stopRef.current = false;
    setLinesFront([]); setLinesMiddle([]); setLinesBack([]);
    setAttempts(0); setElapsed(0); setCracked(null); setRunning(true);

    const target = await hashWith(hashType, pwd);
    const hasher = await makeHasher(hashType);
    const delay = speedToDelay(speed);
    const batch = speedToBatch(speed);
    const total = Math.pow(10, maxDigits);
    const t0 = performance.now();
    pushAll(`▸ charset: 0-9   length: 1..${maxDigits}   hash: ${hashType}`, "dim");
    pushAll(`▸ 3 terminals racing in parallel (keyspace split in thirds)`, "dim");

    const counts: Record<WorkerKind, number> = { front: 0, middle: 0, back: 0 };
    const foundRef: { value: string | null; by: WorkerKind | null } = { value: null, by: null };
    const totalAttempts = () => counts.front + counts.middle + counts.back;

    const a = Math.floor(total / 3);
    const b = Math.floor((2 * total) / 3);

    const runWorker = async (w: WorkerKind) => {
      let from: number, to: number, step: 1 | -1;
      if (w === "front") { from = 0; to = a; step = 1; }
      else if (w === "middle") { from = a; to = b; step = 1; }
      else { from = total - 1; to = b - 1; step = -1; }

      let i = from;
      while (step === 1 ? i < to : i > to) {
        if (stopRef.current || foundRef.value) return;
        const candidate = String(i).padStart(maxDigits, "0");
        const h = await hasher(candidate);
        counts[w]++;
        if (counts[w] % batch === 0) {
          pushTo(w, `Trying: ${candidate}`);
          setAttempts(totalAttempts());
          setElapsed(performance.now() - t0);
          await new Promise((r) => setTimeout(r, 0));
        } else if (delay > 0 && counts[w] % 5 === 0) {
          pushTo(w, `Trying: ${candidate}`);
        }
        if (h === target) {
          foundRef.value = candidate;
          foundRef.by = w;
          return;
        }
        if (delay > 0) await new Promise((r) => setTimeout(r, delay));
        i += step;
      }
    };

    await Promise.all([runWorker("front"), runWorker("middle"), runWorker("back")]);

    const ms = performance.now() - t0;
    const count = totalAttempts();
    setAttempts(count);
    setElapsed(ms);
    if (stopRef.current && !foundRef.value) {
      pushAll("✖ stopped by user", "err");
    }
    if (foundRef.value) {
      const by = foundRef.by!;
      pushTo(by, `✔ FOUND: ${foundRef.value}`, "ok");
      pushAll(`✔ Cracked by ${WORKER_LABEL[by]}`, "ok");
      setCracked(foundRef.value);
      confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
      recordHardest({
        mode: "Numeric",
        value: foundRef.value,
        hashType,
        detail: `Max digits ${maxDigits}`,
        attempts: count,
        elapsedMs: ms,
      });
    } else if (!stopRef.current) {
      pushAll("Not found in keyspace — did you select the right hash type?", "err");
      recordFailure({
        mode: "Numeric",
        target: pwd,
        hashType,
        detail: `Max digits ${maxDigits} · keyspace ${total.toLocaleString()}`,
        attempts: total,
        elapsedMs: ms,
      });
    }
    setRunning(false);
  };

  const aps = elapsed > 0 ? Math.round((attempts / elapsed) * 1000) : 0;

  return (
    <div className="grid gap-4 md:grid-cols-2 fade-in">
      <Card className="p-4 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="num-pwd">Numeric password to crack</Label>
          <Input
            id="num-pwd"
            value={pwd}
            placeholder="e.g. 4819"
            inputMode="numeric"
            onChange={(e) => setPwd(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !running && start()}
            disabled={running}
            className="font-mono border-2 border-primary"
          />
          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label>Hash type</Label>
            <Select value={hashType} onValueChange={(v) => setHashType(v as HashType)} disabled={running}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="plain">Plain text</SelectItem>
                <SelectItem value="MD5">MD5</SelectItem>
                <SelectItem value="SHA-1">SHA-1</SelectItem>
                <SelectItem value="SHA-256">SHA-256</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Max digits (1–8)</Label>
            <Input
              type="number"
              min={1}
              max={8}
              value={maxDigits}
              onChange={(e) => setMaxDigits(Math.max(1, Math.min(8, Number(e.target.value) || 1)))}
              disabled={running}
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Speed: {["Slow", "Medium", "Fast"][speed]}</Label>
          <Slider value={[speed]} min={0} max={2} step={1} onValueChange={(v) => setSpeed(v[0])} disabled={running} />
        </div>
        <div className="flex gap-2">
          {!running ? (
            <Button onClick={start} className="bg-emerald-500 hover:bg-emerald-600 text-black font-semibold">Start cracking</Button>
          ) : (
            <Button onClick={() => (stopRef.current = true)} variant="destructive">Stop</Button>
          )}
          <Button onClick={reset} variant="outline" disabled={running}>Reset</Button>
        </div>
      </Card>
      <Card className="p-4 space-y-3">
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <Badge variant="secondary" className="font-mono">Attempts: {attempts.toLocaleString()}</Badge>
          <Badge variant="secondary" className="font-mono">Elapsed: {(elapsed / 1000).toFixed(2)}s</Badge>
          <Badge variant="secondary" className="font-mono">{aps.toLocaleString()} / sec</Badge>
        </div>
        {cracked && <CrackedBanner value={cracked} />}
        <div className="space-y-2">
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.front}</div>
            <Terminal lines={linesFront} className="h-32" />
          </div>
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.middle}</div>
            <Terminal lines={linesMiddle} className="h-32" />
          </div>
          <div>
            <div className="text-xs font-mono text-muted-foreground mb-1">{WORKER_LABEL.back}</div>
            <Terminal lines={linesBack} className="h-32" />
          </div>
        </div>
      </Card>
    </div>
  );
}