import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { NumericCracker } from "@/components/cracklab/NumericCracker";
import { AlphabeticCracker } from "@/components/cracklab/AlphabeticCracker";
import { PatternCracker } from "@/components/cracklab/PatternCracker";
import { HowItWorks } from "@/components/cracklab/HowItWorks";
import { FailuresPanel } from "@/components/cracklab/FailuresPanel";
import { WelcomePage } from "@/components/cracklab/WelcomePage";
import { ShieldAlert, Terminal as TerminalIcon } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CrackLab — Educational Password Cracking Simulator" },
      { name: "description", content: "A browser-only learning tool that visualizes how brute-force attacks work against numeric, alphabetic, and Android-pattern passwords." },
      { property: "og:title", content: "CrackLab — Educational Password Cracking Simulator" },
      { property: "og:description", content: "Learn how brute-force attacks work, entirely in your browser." },
    ],
  }),
  component: Index,
});

function Index() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [accepted, setAccepted] = useState(false);
  const [checked, setChecked] = useState(false);
  const [tab, setTab] = useState("numeric");

  useEffect(() => {
    if (typeof window !== "undefined") {
      if (localStorage.getItem("cracklab.welcomed") === "1") {
        setShowWelcome(false);
      }
      if (localStorage.getItem("cracklab.accepted") === "1") {
        setAccepted(true);
      }
    }
  }, []);

  const handleStart = () => {
    localStorage.setItem("cracklab.welcomed", "1");
    setShowWelcome(false);
  };

  const accept = () => {
    localStorage.setItem("cracklab.accepted", "1");
    setAccepted(true);
  };

  if (showWelcome) {
    return <WelcomePage onStart={handleStart} />;
  }

  return (
    <div className="dark min-h-screen bg-background text-foreground flex flex-col">
      <Dialog open={!accepted}>
        <DialogContent className="max-w-lg [&>button.absolute]:hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="h-5 w-5 text-emerald-400" />
              CrackLab — Educational Password Cracking Simulator
            </DialogTitle>
            <DialogDescription className="pt-2 leading-relaxed">
              CrackLab is a <b>learning tool</b>. It simulates how brute-force attacks work against weak
              passwords so you can understand why length and entropy matter. Everything runs <b>entirely in your
              browser</b> — nothing is sent to a server.
              <br /><br />
              Use it only on passwords you own. Cracking accounts you don't own is illegal in most jurisdictions.
            </DialogDescription>
          </DialogHeader>
          <label className="flex items-start gap-2 text-sm cursor-pointer mt-2">
            <Checkbox checked={checked} onCheckedChange={(v) => setChecked(!!v)} className="mt-0.5" />
            <span>I understand this is for educational use on my own passwords only.</span>
          </label>
          <DialogFooter>
            <Button onClick={accept} disabled={!checked} className="bg-emerald-500 hover:bg-emerald-600 text-black font-semibold">
              Enter CrackLab
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <header className="border-b border-border bg-card/40 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <TerminalIcon className="h-6 w-6 text-emerald-400" />
          <div>
            <h1 className="text-lg font-bold font-mono tracking-tight">CrackLab<span className="text-emerald-400">_</span></h1>
            <p className="text-xs text-muted-foreground">Educational Password Cracking Simulator · browser-only</p>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto p-4">
        <Tabs value={tab} onValueChange={setTab} className="space-y-4">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="numeric">Numeric</TabsTrigger>
            <TabsTrigger value="alpha">Alphabetic</TabsTrigger>
            <TabsTrigger value="pattern">Pattern</TabsTrigger>
            <TabsTrigger value="vault">Vault</TabsTrigger>
            <TabsTrigger value="how">How it works</TabsTrigger>
          </TabsList>
          <TabsContent value="numeric"><NumericCracker key="n" /></TabsContent>
          <TabsContent value="alpha"><AlphabeticCracker key="a" /></TabsContent>
          <TabsContent value="pattern"><PatternCracker key="p" /></TabsContent>
          <TabsContent value="vault"><FailuresPanel /></TabsContent>
          <TabsContent value="how"><HowItWorks /></TabsContent>
        </Tabs>
      </main>

      <footer className="border-t border-border bg-card/40 mt-6">
        <div className="max-w-6xl mx-auto px-4 py-3 text-xs text-muted-foreground text-center font-mono">
          CrackLab is for educational use only. Only test passwords you own. No data leaves your browser.
        </div>
      </footer>
    </div>
  );
}
